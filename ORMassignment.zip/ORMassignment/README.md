Assignment: ORM Supplementary Assignment

Lecture: Udara San

Objective:

This assignment aims to evaluate your proficiency in Hibernate Query Language (HQL),
understanding of cascade operations, and the usage of the @JoinColumn annotation.
Scenario:
Consider a simple library management system with two entities: Author and Book. An Author
can write multiple Books. Your task is to implement various operations using Hibernate.
Entities:
1. Author:
- Attributes:
- id (Primary Key)
- name
- Relationship:
- One author can have multiple books.
- Annotations:
- @Entity
- @Id
- @GeneratedValue
- @OneToMany with mappedBy pointing to author field in Book entity.
2. Book:
- Attributes:
- id (Primary Key)
- title
- publicationYear
- price
- Relationship:
- Many books can be written by one author.
- Annotations:
- @Entity
- @Id
- @GeneratedValue
- @ManyToOne with @JoinColumn pointing to author_id in database.
  Assignments:
1. Write an HQL query to retrieve all books published after the year 2010.
2. Write an HQL update query to increase the price of all books published by a specific
   author by 10%.
3. Implement a method to delete an author and cascade the deletion to all associated books
   using appropriate cascade options.
4. Write an HQL query to find the average price of all books.
5. Write an HQL query to retrieve all authors along with the count of books they have written.
6. Write an HQL query using named parameters to retrieve books written by authors from a
   specific country.
7. Define bidirectional one-to-many relationship between Author and Book entities using
   @JoinColumn annotation.
10. Write an HQL query to find authors who have written more than the average number of
    books.