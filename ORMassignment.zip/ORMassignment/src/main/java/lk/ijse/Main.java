/*package lk.ijse;

import com.mysql.cj.Session;
import lk.ijse.config.FactoryConfiguration;
import lk.ijse.entity.Author;
import lk.ijse.entity.Book;



public class Main {
    public static void main(String[] args) {
        FactoryConfiguration factoryConfiguration = FactoryConfiguration.getInstance();
        Session session = factoryConfiguration.getSession();

        session.begin
        Author author = new Author();
        author.setName("ABC");

        Book book = new Book();
        book.setTitle("abc book");
        book.setPublicationYear(2022);
        book.setPrice(1000.00);
        book.setAuthor(author);

        session.beginTransaction();

        session.save(author);
        session.save(book);

        session.getTransaction().commit();

        session.close();
    }
}*/

package lk.ijse;
import org.hibernate.Session;
import lk.ijse.config.FactoryConfiguration;
import lk.ijse.entity.Author;
import lk.ijse.entity.Book;
import org.hibernate.query.Query;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        FactoryConfiguration factoryConfiguration = FactoryConfiguration.getInstance();
        Session session = (Session) factoryConfiguration.getSession();

        try {

            session.beginTransaction();

            Author specificAuthor = new Author();
            specificAuthor.setId(1);
            int authorId = 1;
            String specificCountry = "United States";


            //1.Retrieve all books published after the year 2010
            Query<Book> query1 = session.createQuery("FROM Book b WHERE b.publicationYear > 2010", Book.class);
            List<Book> booksPublishedAfter2010 = query1.getResultList();
            System.out.println("Books published after 2010:");
            for (Book b : booksPublishedAfter2010) {
                System.out.println(b.getTitle());
            }

            //2.Update the price of all books published by a specific author by 10%
            Query<Book> query2 = session.createQuery("UPDATE Book b SET b.price = b.price * 1.1 WHERE b.author = :author", Book.class);
            query2.setParameter("author", specificAuthor);
            int updatedCount = query2.executeUpdate();
            System.out.println("Number of books updated: " + updatedCount);

            //3.Implement a method to delete an author and cascade the deletion to all associated books
            Author authorToDelete = session.get(Author.class, authorId);
            session.delete(authorToDelete);

            //4.Find the average price of all books
            Query<Double> query4 = session.createQuery("SELECT AVG(b.price) FROM Book b", Double.class);
            Double averagePrice = query4.uniqueResult();
            System.out.println("Average price of all books: " + averagePrice);

            //5.Retrieve all authors along with the count of books they have written
            Query<Object[]> query5 = session.createQuery("SELECT a.name, COUNT(b) FROM Author a JOIN a.books b GROUP BY a.name", Object[].class);
            List<Object[]> authorsWithBookCounts = query5.getResultList();
            System.out.println("Authors with the count of books they have written:");
            for (Object[] result : authorsWithBookCounts) {
                System.out.println("Author: " + result[0] + ", Number of Books: " + result[1]);
            }

            //6.Retrieve books written by authors from a specific country using named parameters
            Query<Book> query6 = session.createQuery("FROM Book b WHERE b.author.country = :country", Book.class);
            query6.setParameter("country", specificCountry);
            List<Book> booksFromSpecificCountry;
            booksFromSpecificCountry = query6.getResultList();
            System.out.println("Books written by authors from " + specificCountry + ":");
            for (Book b : booksFromSpecificCountry) {
                System.out.println(b.getTitle());
            }

            //7.Define bidirectional one-to-many relationship between Author and Book entities using @JoinColumn annotation
            //Each Author can have many Books.Annotated with @JoinColumn in Book entity to specify foreign key column linking to Author. Allows efficient navigation between entities.


            //10.Find authors who have written more than the average number of books
            Query<Author> query10 = session.createQuery("SELECT a FROM Author a WHERE SIZE(a.books) > (SELECT AVG(SIZE(b.books)) FROM Author b)", Author.class);
            List<Author> authorsWithMoreBooksThanAverage = query10.getResultList();
            System.out.println("Authors who have written more than the average number of books:");
            for (Author a : authorsWithMoreBooksThanAverage) {
                System.out.println(a.getName());
            }

            Author author = new Author();
            author.setName("ABC");

            Book book = new Book();
            book.setTitle("abc book");
            book.setPublicationYear(2022);
            book.setPrice(1000.00);
            book.setAuthor(author);

            session.save(author);
            session.save(book);

            session.getTransaction().commit();
        } catch (Exception ex) {
            if (session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
            ex.printStackTrace();
        } finally {
            session.close();
        }
    }
}
