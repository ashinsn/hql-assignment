package lk.ijse.config;

import com.mysql.cj.Session;
import lk.ijse.entity.Author;
import lk.ijse.entity.Book;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FactoryConfiguration {
    private static FactoryConfiguration factoryConfiguration;
    private SessionFactory sessionFactory;

    private FactoryConfiguration() {
        Configuration configuration =
                new Configuration().configure()
                        .addAnnotatedClass(Author.class)
                        .addAnnotatedClass(Book.class);
        sessionFactory = configuration.buildSessionFactory();
    }

    public static FactoryConfiguration getInstance() {
        return (factoryConfiguration == null) ?
                factoryConfiguration =
                        new FactoryConfiguration() : factoryConfiguration;
    }

    public Session getSession() {
        return (Session) sessionFactory.openSession();
    }
}




